export const config = {
  runtime: 'edge',
};

export default async function handler(request) {
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, HEAD, POST, OPTIONS",
        "Access-Control-Allow-Headers": "*",
        "Access-Control-Max-Age": "86400",
      },
    });
  }

  if (request.headers.get("upgrade") === "websocket") {
    const targetWispServer = "https://wisp.mercurywork.shop/";
    try {
      return await fetch(targetWispServer, {
        method: request.method,
        headers: request.headers,
        body: request.body,
        redirect: "manual"
      });
    } catch (err) {
      return new Response(`Gateway Connection Error: ${err.message}`, { status: 502 });
    }
  }

  return new Response("Wisp Gateway Online", {
    status: 200,
    headers: {
      "Content-Type": "text/plain",
      "Access-Control-Allow-Origin": "*",
      "Cache-Control": "no-store"
    }
  });
}
